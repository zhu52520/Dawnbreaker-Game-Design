#include "3.h"

C::C()
{
    int i =1;
}