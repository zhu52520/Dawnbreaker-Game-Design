class C
{
public:
    C();
};