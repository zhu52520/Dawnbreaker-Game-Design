class B
{
public:
    B();
};