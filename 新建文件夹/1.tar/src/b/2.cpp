#include "2.h"

B::B()
{
    int i =1;
}