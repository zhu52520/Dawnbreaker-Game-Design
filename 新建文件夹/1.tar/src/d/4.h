class D
{
public:
    D();
};