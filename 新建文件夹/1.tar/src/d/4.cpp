#include "4.h"

D::D()
{
    int i =1;
}