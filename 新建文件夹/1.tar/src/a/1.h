class A
{
public:
    A();
};