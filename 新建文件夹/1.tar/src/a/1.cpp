#include "1.h"

A::A()
{
    int i =1;
}